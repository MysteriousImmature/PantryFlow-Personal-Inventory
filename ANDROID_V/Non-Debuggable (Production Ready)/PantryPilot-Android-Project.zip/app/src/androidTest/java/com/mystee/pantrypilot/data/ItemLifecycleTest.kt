package com.mystee.pantrypilot.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.mystee.pantrypilot.data.local.GroceryListEntity
import com.mystee.pantrypilot.data.local.ItemEntity
import com.mystee.pantrypilot.data.local.LocationEntity
import com.mystee.pantrypilot.data.local.MainCategoryEntity
import com.mystee.pantrypilot.data.local.PantryDatabase
import com.mystee.pantrypilot.data.local.UnitEntity
import java.time.Instant
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ItemLifecycleTest {
    private lateinit var database: PantryDatabase

    @Before
    fun createDatabase() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, PantryDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val catalog = database.catalogDao()
        catalog.insertLocation(LocationEntity(id = "location", name = "Pantry"))
        catalog.insertMainCategory(MainCategoryEntity(id = "category", name = "Food"))
        catalog.insertUnit(UnitEntity(id = "unit", name = "Piece", abbreviation = "pc"))
        database.groceryListDao().insert(GroceryListEntity(id = "list", name = "Groceries"))
    }

    @After fun closeDatabase() = database.close()

    @Test
    fun consumeNeverMakesStockNegative() = runBlocking {
        val dao = database.itemDao()
        dao.insert(item(stock = 2.0))

        dao.consume("item", 5.0, Instant.now().toEpochMilli())

        assertEquals(0.0, dao.get("item")!!.inStockQuantity, 0.0)
    }

    @Test
    fun purchasedQuantityIsRestockedAndShoppingStateIsCleared() = runBlocking {
        val dao = database.itemDao()
        dao.insert(item(stock = 2.0, toBuy = 3.0, purchased = true))

        val changed = dao.restockPurchasedTransaction("list", Instant.now().toEpochMilli())
        val result = dao.get("item")!!

        assertEquals(1, changed)
        assertEquals(5.0, result.inStockQuantity, 0.0)
        assertEquals(0.0, result.toBuyQuantity, 0.0)
        assertEquals(null, result.groceryListId)
        assertFalse(result.isPurchased)
        assertEquals(0, dao.observeShoppingItems("list").first().size)
    }

    private fun item(
        stock: Double,
        toBuy: Double = 0.0,
        purchased: Boolean = false
    ) = ItemEntity(
        id = "item",
        name = "Rice",
        locationId = "location",
        mainCategoryId = "category",
        unitId = "unit",
        groceryListId = "list".takeIf { toBuy > 0 },
        inStockQuantity = stock,
        toBuyQuantity = toBuy,
        lowStockThreshold = 1.0,
        isPurchased = purchased
    )
}
