package com.mystee.pantrypilot.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storage
import androidx.compose.ui.graphics.vector.ImageVector

object AppIcons {
    val choices: Map<String, ImageVector> = linkedMapOf(
        "pantry" to Icons.Default.Inventory2,
        "fridge" to Icons.Default.Kitchen,
        "freezer" to Icons.Default.AcUnit,
        "home" to Icons.Default.Home,
        "storage" to Icons.Default.Storage,
        "shopping" to Icons.Default.ShoppingCart,
        "category" to Icons.Default.Category
    )

    fun fromKey(key: String): ImageVector = choices[key] ?: Icons.Default.Inventory2
}
