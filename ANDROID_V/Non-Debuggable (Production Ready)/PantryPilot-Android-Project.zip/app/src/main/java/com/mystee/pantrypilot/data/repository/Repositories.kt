package com.mystee.pantrypilot.data.repository

import androidx.room.withTransaction
import com.mystee.pantrypilot.data.local.AppSettingEntity
import com.mystee.pantrypilot.data.local.CatalogDao
import com.mystee.pantrypilot.data.local.CatalogSnapshot
import com.mystee.pantrypilot.data.local.GroceryListDao
import com.mystee.pantrypilot.data.local.GroceryListEntity
import com.mystee.pantrypilot.data.local.GroceryListSummary
import com.mystee.pantrypilot.data.local.ItemDao
import com.mystee.pantrypilot.data.local.ItemDetails
import com.mystee.pantrypilot.data.local.ItemEntity
import com.mystee.pantrypilot.data.local.LocationEntity
import com.mystee.pantrypilot.data.local.LowStockPrompt
import com.mystee.pantrypilot.data.local.MainCategoryEntity
import com.mystee.pantrypilot.data.local.PantryDatabase
import com.mystee.pantrypilot.data.local.SettingsDao
import com.mystee.pantrypilot.data.local.SubcategoryEntity
import com.mystee.pantrypilot.data.local.ThemeMode
import com.mystee.pantrypilot.data.local.UnitEntity
import java.time.Instant
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.max
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

@Singleton
class InventoryRepository @Inject constructor(
    private val database: PantryDatabase,
    private val itemDao: ItemDao
) {
    val inventory: Flow<List<ItemDetails>> = itemDao.observeInventory()

    suspend fun save(item: ItemEntity) {
        validate(item)
        val existing = itemDao.get(item.id)
        val normalized = item.copy(
            name = item.name.trim(),
            inStockQuantity = item.inStockQuantity.coerceAtLeast(0.0),
            toBuyQuantity = item.toBuyQuantity.coerceAtLeast(0.0),
            lowStockThreshold = item.lowStockThreshold.coerceAtLeast(0.0),
            pricePerUnitCents = item.pricePerUnitCents.coerceAtLeast(0),
            groceryListId = item.groceryListId.takeIf { item.toBuyQuantity > 0 },
            isPurchased = item.isPurchased && item.toBuyQuantity > 0,
            updatedAt = Instant.now()
        )
        if (existing == null) itemDao.insert(normalized) else itemDao.update(normalized)
    }

    suspend fun delete(item: ItemEntity) = itemDao.delete(item)

    suspend fun increment(itemId: String, amount: Double = 1.0) {
        require(amount > 0) { "Amount must be greater than zero" }
        itemDao.adjustStock(itemId, amount, Instant.now().toEpochMilli())
    }

    /**
     * Atomically removes stock and returns a prompt only when the new quantity is low.
     * The UI decides whether to add the suggested amount to an active grocery list.
     */
    suspend fun consume(itemId: String, amount: Double = 1.0): LowStockPrompt? =
        database.withTransaction {
            require(amount > 0) { "Amount must be greater than zero" }
            check(itemDao.consume(itemId, amount, Instant.now().toEpochMilli()) == 1) {
                "Item was not found"
            }
            val details = checkNotNull(itemDao.getDetails(itemId))
            val item = details.item
            if (item.inStockQuantity < item.lowStockThreshold && item.toBuyQuantity <= 0) {
                LowStockPrompt(
                    item = details,
                    suggestedQuantity = max(1.0, item.lowStockThreshold - item.inStockQuantity)
                )
            } else null
        }

    suspend fun addLowStockToList(itemId: String, listId: String, quantity: Double) {
        require(quantity > 0) { "Quantity must be greater than zero" }
        check(itemDao.addToShoppingList(itemId, listId, quantity, Instant.now().toEpochMilli()) == 1) {
            "The item or active grocery list no longer exists"
        }
    }

    private fun validate(item: ItemEntity) {
        require(item.name.isNotBlank()) { "Item name is required" }
        require(item.inStockQuantity >= 0 && item.toBuyQuantity >= 0) { "Quantities cannot be negative" }
        require(item.lowStockThreshold >= 0) { "Low-stock threshold cannot be negative" }
        require(item.pricePerUnitCents >= 0) { "Price cannot be negative" }
        require((item.groceryListId != null) == (item.toBuyQuantity > 0) || item.toBuyQuantity == 0.0) {
            "Choose a grocery list for items to buy"
        }
    }
}

@Singleton
class ShoppingRepository @Inject constructor(
    private val database: PantryDatabase,
    private val listDao: GroceryListDao,
    private val itemDao: ItemDao
) {
    val activeLists: Flow<List<GroceryListEntity>> = listDao.observeActive()
    val summaries: Flow<List<GroceryListSummary>> = listDao.observeSummaries()

    fun items(listId: String): Flow<List<ItemDetails>> = itemDao.observeShoppingItems(listId)
    suspend fun getList(listId: String): GroceryListEntity? = listDao.get(listId)

    suspend fun saveList(value: GroceryListEntity) {
        require(value.name.isNotBlank()) { "List name is required" }
        require(value.budgetCents >= 0) { "Budget cannot be negative" }
        val normalized = value.copy(name = value.name.trim())
        if (listDao.get(value.id) == null) listDao.insert(normalized) else listDao.update(normalized)
    }

    suspend fun archive(listId: String) {
        val list = checkNotNull(listDao.get(listId)) { "List was not found" }
        listDao.update(list.copy(isArchived = true))
    }

    suspend fun setPurchased(itemId: String, purchased: Boolean) {
        itemDao.setPurchased(itemId, purchased, Instant.now().toEpochMilli())
    }

    /** One-tap restock: purchased shopping quantity becomes home stock, then shopping state is reset. */
    suspend fun finishShopping(listId: String): Int = database.withTransaction {
        itemDao.restockPurchasedTransaction(listId, Instant.now().toEpochMilli())
    }

    suspend fun removeItem(itemId: String) {
        itemDao.removeFromShoppingList(itemId, Instant.now().toEpochMilli())
    }
}

@Singleton
class CatalogRepository @Inject constructor(private val dao: CatalogDao) {
    val snapshot: Flow<CatalogSnapshot> = combine(
        dao.observeLocations(),
        dao.observeMainCategories(),
        dao.observeSubcategories(),
        dao.observeUnits()
    ) { locations, main, sub, units ->
        CatalogSnapshot(locations, main, sub, units)
    }

    suspend fun save(value: LocationEntity, exists: Boolean) {
        require(value.name.isNotBlank()) { "Location name is required" }
        require(value.icon.isNotBlank()) { "Location icon is required" }
        val clean = value.copy(name = value.name.trim())
        if (exists) dao.updateLocation(clean) else dao.insertLocation(clean)
    }
    suspend fun save(value: MainCategoryEntity, exists: Boolean) {
        require(value.name.isNotBlank()) { "Category name is required" }
        val clean = value.copy(name = value.name.trim())
        if (exists) dao.updateMainCategory(clean) else dao.insertMainCategory(clean)
    }
    suspend fun save(value: SubcategoryEntity, exists: Boolean) {
        require(value.name.isNotBlank()) { "Subcategory name is required" }
        val clean = value.copy(name = value.name.trim())
        if (exists) dao.updateSubcategory(clean) else dao.insertSubcategory(clean)
    }
    suspend fun save(value: UnitEntity, exists: Boolean) {
        require(value.name.isNotBlank() && value.abbreviation.isNotBlank()) { "Unit name and abbreviation are required" }
        val clean = value.copy(name = value.name.trim(), abbreviation = value.abbreviation.trim())
        if (exists) dao.updateUnit(clean) else dao.insertUnit(clean)
    }

    suspend fun delete(value: LocationEntity) = dao.deleteLocation(value)
    suspend fun delete(value: MainCategoryEntity) = dao.deleteMainCategory(value)
    suspend fun delete(value: SubcategoryEntity) = dao.deleteSubcategory(value)
    suspend fun delete(value: UnitEntity) = dao.deleteUnit(value)
}

@Singleton
class SettingsRepository @Inject constructor(private val dao: SettingsDao) {
    val themeMode: Flow<ThemeMode> = dao.observe(THEME_MODE).map { raw ->
        runCatching { ThemeMode.valueOf(raw ?: ThemeMode.SYSTEM.name) }.getOrDefault(ThemeMode.SYSTEM)
    }

    suspend fun setThemeMode(value: ThemeMode) = dao.put(AppSettingEntity(THEME_MODE, value.name))

    private companion object { const val THEME_MODE = "theme_mode" }
}
