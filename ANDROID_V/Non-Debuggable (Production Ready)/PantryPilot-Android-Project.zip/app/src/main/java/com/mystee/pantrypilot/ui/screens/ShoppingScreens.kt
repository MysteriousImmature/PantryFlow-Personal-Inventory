package com.mystee.pantrypilot.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mystee.pantrypilot.data.local.GroceryListEntity
import com.mystee.pantrypilot.data.local.ItemDetails
import com.mystee.pantrypilot.ui.components.ItemEditorSheet
import com.mystee.pantrypilot.ui.components.MessageCollector
import com.mystee.pantrypilot.ui.components.money
import com.mystee.pantrypilot.ui.viewmodel.PantryViewModel
import com.mystee.pantrypilot.ui.viewmodel.ShoppingDetailViewModel
import com.mystee.pantrypilot.ui.viewmodel.ShoppingListsViewModel
import java.time.Instant
import kotlin.math.roundToLong

@Composable
fun ShoppingListsScreen(
    onOpenList: (String) -> Unit,
    viewModel: ShoppingListsViewModel = hiltViewModel()
) {
    val summaries by viewModel.summaries.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var showCreate by remember { mutableStateOf(false) }
    var editingList by remember { mutableStateOf<GroceryListEntity?>(null) }
    MessageCollector(viewModel.messages) { snackbar.showSnackbar(it) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, "New list") }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Text(
                "Shopping lists",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(16.dp)
            )
            val active = summaries.filterNot { it.list.isArchived }
            if (active.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Create your first grocery list") }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(items = active, key = { it.list.id }) { summary ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(
                                    Modifier.weight(1f).clickable { onOpenList(summary.list.id) }.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(summary.list.name, style = MaterialTheme.typography.titleLarge)
                                    Text("${summary.purchasedCount}/${summary.itemCount} purchased")
                                    Text("Purchased: ${money(summary.purchasedCostCents)}")
                                    Text("Still planned: ${money(summary.remainingEstimatedCostCents)}")
                                    if (summary.list.budgetCents > 0) {
                                        Text(
                                            "Budget remaining: ${money(summary.remainingBudgetCents)}",
                                            color = if (summary.remainingBudgetCents < 0) MaterialTheme.colorScheme.error
                                                else MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                TextButton(onClick = { editingList = summary.list }) { Text("Edit") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreate || editingList != null) {
        var name by remember(showCreate, editingList?.id) { mutableStateOf(editingList?.name.orEmpty()) }
        var budget by remember(showCreate, editingList?.id) {
            mutableStateOf(editingList?.budgetCents?.div(100.0)?.toString().orEmpty())
        }
        AlertDialog(
            onDismissRequest = { showCreate = false; editingList = null },
            title = { Text(if (editingList == null) "New grocery list" else "Edit grocery list") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") })
                    OutlinedTextField(budget, { budget = it }, label = { Text("Budget") })
                }
            },
            confirmButton = {
                TextButton(
                    enabled = name.isNotBlank(),
                    onClick = {
                        viewModel.save(
                            editingList?.copy(
                                name = name.trim(),
                                budgetCents = ((budget.toDoubleOrNull() ?: 0.0) * 100).roundToLong()
                            ) ?: GroceryListEntity(
                                    name = name.trim(),
                                    budgetCents = ((budget.toDoubleOrNull() ?: 0.0) * 100).roundToLong(),
                                    createdAt = Instant.now()
                                )
                        )
                        showCreate = false
                        editingList = null
                    }
                ) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showCreate = false; editingList = null }) { Text("Cancel") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingDetailScreen(
    onBack: () -> Unit,
    viewModel: ShoppingDetailViewModel = hiltViewModel(),
    pantryViewModel: PantryViewModel = hiltViewModel()
) {
    val items by viewModel.items.collectAsStateWithLifecycle()
    val summaries by viewModel.summaries.collectAsStateWithLifecycle()
    val catalog by pantryViewModel.catalog.collectAsStateWithLifecycle()
    val lists by pantryViewModel.activeLists.collectAsStateWithLifecycle()
    val summary = summaries.firstOrNull { it.list.id == viewModel.listId }
    val snackbar = remember { SnackbarHostState() }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ItemDetails?>(null) }
    var confirmFinish by remember { mutableStateOf(false) }
    MessageCollector(viewModel.messages) { snackbar.showSnackbar(it) }
    MessageCollector(pantryViewModel.messages) { snackbar.showSnackbar(it) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(summary?.list?.name ?: "Shopping list") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") } }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Add item") }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            summary?.let {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Purchased ${money(it.purchasedCostCents)}")
                        Text("Remaining items ${money(it.remainingEstimatedCostCents)}")
                    }
                    Button(onClick = { confirmFinish = true }, enabled = it.purchasedCount > 0) {
                        Text("Finish shopping")
                    }
                }
            }
            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No items on this list. Tap + to add one.")
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(items = items, key = { it.item.id }) { details ->
                        ShoppingItemRow(
                            details,
                            onChecked = { viewModel.setPurchased(details.item.id, it) },
                            onEdit = { editing = details },
                            onRemove = { viewModel.remove(details.item.id) }
                        )
                    }
                }
            }
        }
    }

    if (showAdd || editing != null) {
        ItemEditorSheet(
            item = editing?.item,
            catalog = catalog,
            groceryLists = lists,
            forcedListId = viewModel.listId,
            onDismiss = { showAdd = false; editing = null },
            onSave = pantryViewModel::save
        )
    }

    if (confirmFinish) {
        AlertDialog(
            onDismissRequest = { confirmFinish = false },
            title = { Text("Move purchased items to pantry?") },
            text = { Text("Checked quantities will be added to home stock and removed from this list.") },
            confirmButton = {
                TextButton(onClick = { viewModel.finishShopping(); confirmFinish = false }) { Text("Restock") }
            },
            dismissButton = { TextButton(onClick = { confirmFinish = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ShoppingItemRow(
    details: ItemDetails,
    onChecked: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onRemove: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = details.item.isPurchased, onCheckedChange = onChecked)
            Column(Modifier.weight(1f)) {
                Text(details.item.name, style = MaterialTheme.typography.titleMedium)
                Text("${details.item.toBuyQuantity} ${details.unit.abbreviation} • ${money((details.item.toBuyQuantity * details.item.pricePerUnitCents).roundToLong())}")
            }
            TextButton(onClick = onEdit) { Text("Edit") }
            IconButton(onClick = onRemove) { Icon(Icons.Default.Delete, "Remove") }
        }
    }
}
