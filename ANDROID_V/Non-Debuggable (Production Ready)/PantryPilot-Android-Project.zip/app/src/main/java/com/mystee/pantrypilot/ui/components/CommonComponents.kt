package com.mystee.pantrypilot.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mystee.pantrypilot.data.local.CatalogSnapshot
import com.mystee.pantrypilot.data.local.GroceryListEntity
import com.mystee.pantrypilot.data.local.ItemEntity
import com.mystee.pantrypilot.data.local.newId
import java.text.NumberFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import kotlin.math.roundToLong
import kotlinx.coroutines.flow.Flow

fun money(cents: Long): String = NumberFormat.getCurrencyInstance().format(cents / 100.0)

@Composable
fun MessageCollector(messages: Flow<String>, onMessage: suspend (String) -> Unit) {
    LaunchedEffect(messages) { messages.collect { onMessage(it) } }
}

@Composable
fun <T> DropdownSelector(
    label: String,
    values: List<T>,
    selected: T?,
    display: (T) -> String,
    onSelected: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedTextField(
            value = selected?.let(display).orEmpty(),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { IconButton(onClick = { expanded = true }) { Icon(Icons.Default.ExpandMore, null) } },
            modifier = Modifier.fillMaxWidth().clickable { expanded = true }
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            values.forEach { value ->
                DropdownMenuItem(
                    text = { Text(display(value)) },
                    onClick = { onSelected(value); expanded = false }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItemEditorSheet(
    item: ItemEntity?,
    catalog: CatalogSnapshot,
    groceryLists: List<GroceryListEntity>,
    forcedListId: String? = null,
    onDismiss: () -> Unit,
    onSave: (ItemEntity) -> Unit
) {
    val defaultLocation = item?.locationId ?: catalog.locations.firstOrNull()?.id
    val defaultMain = item?.mainCategoryId ?: catalog.mainCategories.firstOrNull()?.id
    val defaultUnit = item?.unitId ?: catalog.units.firstOrNull()?.id
    var name by remember(item?.id) { mutableStateOf(item?.name.orEmpty()) }
    var locationId by remember(item?.id) { mutableStateOf(defaultLocation) }
    var mainCategoryId by remember(item?.id) { mutableStateOf(defaultMain) }
    var subcategoryId by remember(item?.id) { mutableStateOf(item?.subcategoryId) }
    var unitId by remember(item?.id) { mutableStateOf(defaultUnit) }
    var stock by remember(item?.id) { mutableStateOf(item?.inStockQuantity?.toString() ?: "0") }
    var threshold by remember(item?.id) { mutableStateOf(item?.lowStockThreshold?.toString() ?: "0") }
    var price by remember(item?.id) { mutableStateOf(item?.pricePerUnitCents?.div(100.0)?.toString() ?: "0") }
    var toBuy by remember(item?.id) {
        mutableStateOf(if (forcedListId != null && (item?.toBuyQuantity ?: 0.0) <= 0) "1" else item?.toBuyQuantity?.toString() ?: "0")
    }
    var groceryListId by remember(item?.id, forcedListId) {
        mutableStateOf(forcedListId ?: item?.groceryListId)
    }
    var expirationDate by remember(item?.id) { mutableStateOf(item?.expirationDate) }
    var showDatePicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val filteredSubcategories = catalog.subcategories.filter { it.mainCategoryId == mainCategoryId }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(if (item == null) "Add item" else "Edit item", style = MaterialTheme.typography.headlineSmall)
            OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
            DropdownSelector(
                "Storage location", catalog.locations,
                catalog.locations.firstOrNull { it.id == locationId }, { it.name }, { locationId = it.id }
            )
            DropdownSelector(
                "Main category", catalog.mainCategories,
                catalog.mainCategories.firstOrNull { it.id == mainCategoryId }, { it.name }, {
                    mainCategoryId = it.id
                    subcategoryId = null
                }
            )
            if (filteredSubcategories.isNotEmpty()) {
                DropdownSelector(
                    "Subcategory (optional)", filteredSubcategories,
                    filteredSubcategories.firstOrNull { it.id == subcategoryId }, { it.name }, { subcategoryId = it.id }
                )
            }
            DropdownSelector(
                "Unit", catalog.units, catalog.units.firstOrNull { it.id == unitId },
                { "${it.name} (${it.abbreviation})" }, { unitId = it.id }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("In stock", stock, { stock = it }, Modifier.weight(1f))
                NumberField("Low at", threshold, { threshold = it }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("Price / unit", price, { price = it }, Modifier.weight(1f))
                NumberField("To buy", toBuy, { toBuy = it }, Modifier.weight(1f))
            }
            if ((toBuy.toDoubleOrNull() ?: 0.0) > 0) {
                DropdownSelector(
                    "Grocery list", groceryLists,
                    groceryLists.firstOrNull { it.id == groceryListId }, { it.name }, { groceryListId = it.id }
                )
            }
            OutlinedButton(onClick = { showDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.CalendarMonth, null)
                Spacer(Modifier.width(8.dp))
                Text(expirationDate?.toString() ?: "Set expiration date")
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    val location = locationId
                    val main = mainCategoryId
                    val unit = unitId
                    val buyQuantity = toBuy.toDoubleOrNull() ?: 0.0
                    error = when {
                        name.isBlank() -> "Enter an item name"
                        location == null || main == null || unit == null -> "Create or select a location, category, and unit"
                        buyQuantity > 0 && groceryListId == null -> "Choose a grocery list"
                        else -> null
                    }
                    if (error == null) {
                        val now = Instant.now()
                        onSave(
                            ItemEntity(
                                id = item?.id ?: newId(),
                                name = name.trim(),
                                locationId = location!!,
                                mainCategoryId = main!!,
                                subcategoryId = subcategoryId,
                                unitId = unit!!,
                                groceryListId = groceryListId.takeIf { buyQuantity > 0 },
                                inStockQuantity = stock.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0,
                                toBuyQuantity = buyQuantity.coerceAtLeast(0.0),
                                lowStockThreshold = threshold.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0,
                                pricePerUnitCents = ((price.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0) * 100).roundToLong(),
                                expirationDate = expirationDate,
                                isPurchased = item?.isPurchased ?: false,
                                createdAt = item?.createdAt ?: now,
                                updatedAt = now
                            )
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save") }
        }
    }

    if (showDatePicker) {
        val initialMillis = expirationDate?.atStartOfDay()?.toInstant(ZoneOffset.UTC)?.toEpochMilli()
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    expirationDate = pickerState.selectedDateMillis?.let {
                        Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { expirationDate = null; showDatePicker = false }) { Text("Clear") } }
        ) { DatePicker(pickerState) }
    }
}

@Composable
private fun NumberField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = { raw -> if (raw.isEmpty() || raw.matches(Regex("\\d*(?:\\.\\d*)?"))) onValue(raw) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = modifier
    )
}

@Composable
fun ColorDot(colorArgb: Long, modifier: Modifier = Modifier) {
    Box(modifier.size(18.dp).background(Color(colorArgb), CircleShape))
}
