package com.mystee.pantrypilot.data.backup

import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.OpenableColumns
import androidx.room.withTransaction
import com.mystee.pantrypilot.data.local.BackupSummary
import com.mystee.pantrypilot.data.local.PantryDatabase
import com.mystee.pantrypilot.data.local.RestoreMode
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.OutputStreamWriter
import java.time.Instant
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class RestorePlan(
    val mode: RestoreMode,
    val summary: BackupSummary,
    internal val statements: List<String>
)

@Singleton
class BackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val database: PantryDatabase
) {
    private val resolver: ContentResolver get() = context.contentResolver

    suspend fun exportSql(uri: Uri): BackupSummary = withContext(Dispatchers.IO) {
        database.withTransaction {
            val counts = linkedMapOf<String, Int>()
            resolver.openOutputStream(uri, "w")!!.bufferedWriter(Charsets.UTF_8).use { writer ->
                writer.appendLine(SQL_HEADER)
                writer.appendLine("-- generated_at=${Instant.now()}")
                writer.appendLine("-- schema_version=1")
                TABLES.forEach { spec ->
                    var count = 0
                    database.openHelper.readableDatabase.query(
                        "SELECT ${spec.columns.joinToString(",")} FROM ${spec.name}"
                    ).use { cursor ->
                        while (cursor.moveToNext()) {
                            writer.appendLine(spec.statement(cursor.rowValues()))
                            count++
                        }
                    }
                    counts[spec.name] = count
                }
            }
            BackupSummary("SQL", counts)
        }
    }

    suspend fun exportCsvZip(uri: Uri): BackupSummary = withContext(Dispatchers.IO) {
        database.withTransaction {
            val counts = linkedMapOf<String, Int>()
            ZipOutputStream(BufferedOutputStream(checkNotNull(resolver.openOutputStream(uri, "w")))).use { zip ->
                zip.putNextEntry(ZipEntry("manifest.properties"))
                zip.write("format=$CSV_HEADER\nschemaVersion=1\ngeneratedAt=${Instant.now()}\n".toByteArray())
                zip.closeEntry()
                TABLES.forEach { spec ->
                    zip.putNextEntry(ZipEntry("${spec.name}.csv"))
                    val writer = OutputStreamWriter(zip, Charsets.UTF_8)
                    writer.write(spec.columns.joinToString(",") { csvEncode(it) })
                    writer.write("\n")
                    var count = 0
                    database.openHelper.readableDatabase.query(
                        "SELECT ${spec.columns.joinToString(",")} FROM ${spec.name}"
                    ).use { cursor ->
                        while (cursor.moveToNext()) {
                            val values = cursor.rowValues().map { it?.toString().orEmpty() }
                            writer.write(values.joinToString(",") { csvEncode(it) })
                            writer.write("\n")
                            count++
                        }
                    }
                    writer.flush()
                    zip.closeEntry()
                    counts[spec.name] = count
                }
            }
            BackupSummary("CSV ZIP", counts)
        }
    }

    suspend fun preview(uri: Uri, mode: RestoreMode): RestorePlan = withContext(Dispatchers.IO) {
        val bytes = checkNotNull(resolver.openInputStream(uri)).use(::readLimited)
        val (format, statements) = when {
            bytes.startsWithZipSignature() -> "CSV ZIP" to statementsFromZip(bytes)
            bytes.toString(Charsets.UTF_8).lineSequence().firstOrNull()?.trim() == SQL_HEADER ->
                "SQL" to statementsFromSql(bytes.toString(Charsets.UTF_8))
            displayName(uri).endsWith(".csv", ignoreCase = true) -> {
                val tableName = displayName(uri).substringBeforeLast('.').substringAfterLast('/')
                "CSV" to statementsFromCsv(tableName, bytes.toString(Charsets.UTF_8))
            }
            else -> error("Unsupported backup. Choose a PantryPilot .sql, .csv, or .zip file.")
        }
        val counts = dryRun(statements, mode)
        RestorePlan(mode, BackupSummary(format, counts), statements)
    }

    suspend fun previewCsvFiles(uris: List<Uri>, mode: RestoreMode): RestorePlan = withContext(Dispatchers.IO) {
        require(uris.isNotEmpty()) { "Choose at least one CSV file" }
        val statements = uris.map { uri ->
            val table = displayName(uri).substringBeforeLast('.').substringAfterLast('/')
            val bytes = checkNotNull(resolver.openInputStream(uri)).use(::readLimited)
            table to statementsFromCsv(table, bytes.toString(Charsets.UTF_8))
        }.sortedBy { (table, _) -> TABLES.indexOfFirst { it.name == table } }
            .flatMap { it.second }
        val counts = dryRun(statements, mode)
        RestorePlan(mode, BackupSummary("CSV", counts), statements)
    }

    suspend fun restore(plan: RestorePlan): BackupSummary = withContext(Dispatchers.IO) {
        database.withTransaction {
            if (plan.mode == RestoreMode.REPLACE) clearAllTables()
            plan.statements.forEach { database.openHelper.writableDatabase.execSQL(it) }
            ensureForeignKeys()
        }
        plan.summary
    }

    private suspend fun dryRun(statements: List<String>, mode: RestoreMode): Map<String, Int> {
        require(statements.isNotEmpty()) { "The backup contains no data rows" }
        val counts = statements.groupingBy { tableFromCanonicalStatement(it) }.eachCount().toSortedMap()
        try {
            database.withTransaction {
                if (mode == RestoreMode.REPLACE) clearAllTables()
                statements.forEach { database.openHelper.writableDatabase.execSQL(it) }
                ensureForeignKeys()
                throw PreviewRollback(counts)
            }
        } catch (rollback: PreviewRollback) {
            return rollback.counts
        } catch (error: Exception) {
            throw IllegalArgumentException("Backup validation failed: ${error.message}", error)
        }
        error("Preview transaction unexpectedly committed")
    }

    private fun statementsFromSql(text: String): List<String> {
        require(text.lineSequence().firstOrNull()?.trim() == SQL_HEADER) { "Not a PantryPilot SQL backup" }
        val firstInsert = text.indexOf("INSERT INTO ")
        require(firstInsert >= 0) { "The SQL backup contains no data rows" }
        return splitSqlStatements(text.substring(firstInsert)).map { statement ->
                val table = statement.removePrefix("INSERT INTO ").substringBefore(' ')
                val spec = TABLE_BY_NAME[table] ?: error("Unknown table in SQL backup: $table")
                require(spec.isCanonical(statement)) { "Unsafe or malformed SQL for table $table" }
                statement
            }
    }

    private fun statementsFromZip(bytes: ByteArray): List<String> {
        val output = mutableListOf<String>()
        var manifestSeen = false
        var totalUncompressed = 0L
        ZipInputStream(BufferedInputStream(ByteArrayInputStream(bytes))).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                require(!entry.isDirectory && !entry.name.contains("..") && !entry.name.startsWith('/')) {
                    "Unsafe ZIP entry"
                }
                val entryBytes = readLimited(zip, MAX_BACKUP_BYTES - totalUncompressed)
                totalUncompressed += entryBytes.size
                require(totalUncompressed <= MAX_BACKUP_BYTES) { "Uncompressed backup is too large" }
                if (entry.name == "manifest.properties") {
                    manifestSeen = entryBytes.toString(Charsets.UTF_8).lineSequence()
                        .any { it.trim() == "format=$CSV_HEADER" }
                } else if (entry.name.endsWith(".csv", true)) {
                    val table = entry.name.substringAfterLast('/').substringBeforeLast('.')
                    output += statementsFromCsv(table, entryBytes.toString(Charsets.UTF_8))
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        require(manifestSeen) { "CSV ZIP manifest is missing or incompatible" }
        return output
    }

    private fun statementsFromCsv(tableName: String, text: String): List<String> {
        val spec = TABLE_BY_NAME[tableName] ?: error("CSV filename must match an app table; found $tableName.csv")
        val rows = parseCsv(text)
        require(rows.isNotEmpty()) { "$tableName.csv is empty" }
        require(rows.first() == spec.columns) { "$tableName.csv has an unexpected header" }
        require(rows.size <= MAX_ROWS_PER_FILE + 1) { "$tableName.csv has too many rows" }
        return rows.drop(1).filterNot { row -> row.all(String::isBlank) }.map { row ->
            require(row.size == spec.columns.size) { "$tableName.csv contains a row with the wrong column count" }
            spec.statement(row.mapIndexed { index, value ->
                if (value.isEmpty() && spec.nullableColumns.contains(spec.columns[index])) null else value
            })
        }
    }

    private fun clearAllTables() {
        DELETE_ORDER.forEach { database.openHelper.writableDatabase.execSQL("DELETE FROM $it") }
    }

    private fun ensureForeignKeys() {
        database.openHelper.writableDatabase.query("PRAGMA foreign_key_check").use { cursor ->
            require(!cursor.moveToFirst()) { "Backup contains broken foreign-key relationships" }
        }
        database.openHelper.writableDatabase.query(
            """
            SELECT COUNT(*) FROM items
            WHERE in_stock_quantity < 0 OR to_buy_quantity < 0 OR low_stock_threshold < 0
               OR price_per_unit_cents < 0
               OR (to_buy_quantity > 0 AND grocery_list_id IS NULL)
               OR (to_buy_quantity <= 0 AND grocery_list_id IS NOT NULL)
               OR (is_purchased = 1 AND to_buy_quantity <= 0)
               OR grocery_list_id IN (SELECT id FROM grocery_lists WHERE is_archived = 1)
            """.trimIndent()
        ).use { cursor ->
            require(cursor.moveToFirst() && cursor.getLong(0) == 0L) {
                "Backup contains invalid quantities or shopping-list state"
            }
        }
    }

    private fun displayName(uri: Uri): String {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return uri.lastPathSegment.orEmpty()
    }

    private fun Cursor.rowValues(): List<Any?> = (0 until columnCount).map { index ->
        when (getType(index)) {
            Cursor.FIELD_TYPE_NULL -> null
            Cursor.FIELD_TYPE_INTEGER -> getLong(index)
            Cursor.FIELD_TYPE_FLOAT -> getDouble(index)
            Cursor.FIELD_TYPE_BLOB -> error("BLOB columns are not supported by this backup version")
            else -> getString(index)
        }
    }

    private fun readLimited(input: InputStream, limit: Long = MAX_BACKUP_BYTES): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var total = 0L
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= limit) { "Backup exceeds the ${MAX_BACKUP_BYTES / 1024 / 1024} MB limit" }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private class PreviewRollback(val counts: Map<String, Int>) : RuntimeException()

    private companion object {
        const val SQL_HEADER = "-- PANTRY_PILOT_SQL_V1"
        const val CSV_HEADER = "PANTRY_PILOT_CSV_V1"
        const val MAX_BACKUP_BYTES = 50L * 1024 * 1024
        const val MAX_ROWS_PER_FILE = 100_000
    }
}

private data class TableSpec(
    val name: String,
    val primaryKey: String,
    val columns: List<String>,
    val textColumns: Set<String>,
    val nullableColumns: Set<String> = emptySet()
) {
    private val updateClause = columns.filterNot { it == primaryKey }
        .joinToString(",") { "$it=excluded.$it" }
    private val prefix = "INSERT INTO $name (${columns.joinToString(",")}) VALUES ("
    private val suffix = ") ON CONFLICT($primaryKey) DO UPDATE SET $updateClause;"

    fun statement(values: List<Any?>): String {
        require(values.size == columns.size)
        val encoded = values.mapIndexed { index, value ->
            val column = columns[index]
            when {
                value == null -> "NULL"
                column in textColumns -> "'${value.toString().replace("'", "''")}'"
                value.toString().matches(NUMBER) -> value.toString()
                else -> error("Non-numeric value for $name.$column")
            }
        }
        return prefix + encoded.joinToString(",") + suffix
    }

    fun isCanonical(statement: String): Boolean {
        if (!statement.startsWith(prefix) || !statement.endsWith(suffix)) return false
        val body = statement.removePrefix(prefix).removeSuffix(suffix)
        val values = splitSqlValues(body) ?: return false
        if (values.size != columns.size) return false
        return values.withIndex().all { (index, value) ->
            when {
                value == "NULL" -> columns[index] in nullableColumns
                columns[index] in textColumns -> value.length >= 2 && value.first() == '\'' &&
                    value.last() == '\'' && validQuotedString(value)
                else -> value.matches(NUMBER)
            }
        }
    }
}

private val NUMBER = Regex("-?(?:0|[1-9]\\d*)(?:\\.\\d+)?(?:[eE][+-]?\\d+)?")

private val TABLES = listOf(
    TableSpec("locations", "id", listOf("id", "name", "icon", "color_argb"), setOf("id", "name", "icon")),
    TableSpec("main_categories", "id", listOf("id", "name"), setOf("id", "name")),
    TableSpec("subcategories", "id", listOf("id", "main_category_id", "name"), setOf("id", "main_category_id", "name")),
    TableSpec("units", "id", listOf("id", "name", "abbreviation"), setOf("id", "name", "abbreviation")),
    TableSpec("grocery_lists", "id", listOf("id", "name", "budget_cents", "is_archived", "created_at"), setOf("id", "name")),
    TableSpec(
        "items", "id",
        listOf(
            "id", "name", "location_id", "main_category_id", "subcategory_id", "unit_id",
            "grocery_list_id", "in_stock_quantity", "to_buy_quantity", "low_stock_threshold",
            "price_per_unit_cents", "expiration_date", "is_purchased", "created_at", "updated_at"
        ),
        setOf("id", "name", "location_id", "main_category_id", "subcategory_id", "unit_id", "grocery_list_id", "expiration_date"),
        setOf("subcategory_id", "grocery_list_id", "expiration_date")
    ),
    TableSpec("app_settings", "key", listOf("key", "value"), setOf("key", "value"))
)

private val TABLE_BY_NAME = TABLES.associateBy(TableSpec::name)
private val DELETE_ORDER = listOf(
    "items", "subcategories", "grocery_lists", "units", "main_categories", "locations", "app_settings"
)

private fun tableFromCanonicalStatement(statement: String): String =
    statement.removePrefix("INSERT INTO ").substringBefore(' ')

private fun ByteArray.startsWithZipSignature(): Boolean =
    size >= 4 && this[0] == 0x50.toByte() && this[1] == 0x4B.toByte() &&
        this[2] == 0x03.toByte() && this[3] == 0x04.toByte()

private fun validQuotedString(value: String): Boolean {
    var index = 1
    while (index < value.lastIndex) {
        if (value[index] == '\'') {
            if (index + 1 >= value.lastIndex || value[index + 1] != '\'') return false
            index += 2
        } else index++
    }
    return true
}

private fun splitSqlValues(input: String): List<String>? {
    val values = mutableListOf<String>()
    val current = StringBuilder()
    var quoted = false
    var index = 0
    while (index < input.length) {
        val char = input[index]
        when {
            char == '\'' && quoted && index + 1 < input.length && input[index + 1] == '\'' -> {
                current.append("''")
                index++
            }
            char == '\'' -> { quoted = !quoted; current.append(char) }
            char == ',' && !quoted -> { values += current.toString(); current.clear() }
            else -> current.append(char)
        }
        index++
    }
    if (quoted) return null
    values += current.toString()
    return values
}

/** Splits only on semicolons outside SQL string literals, so multiline names remain restorable. */
private fun splitSqlStatements(input: String): List<String> {
    val statements = mutableListOf<String>()
    val current = StringBuilder()
    var quoted = false
    var index = 0
    while (index < input.length) {
        val char = input[index]
        when {
            char == '\'' && quoted && index + 1 < input.length && input[index + 1] == '\'' -> {
                current.append("''")
                index++
            }
            char == '\'' -> { quoted = !quoted; current.append(char) }
            char == ';' && !quoted -> {
                current.append(char)
                statements += current.toString().trim()
                current.clear()
            }
            else -> current.append(char)
        }
        index++
    }
    require(!quoted && current.toString().isBlank()) { "SQL backup ends with an incomplete statement" }
    return statements
}

private fun csvEncode(value: String): String =
    if (value.any { it == ',' || it == '"' || it == '\n' || it == '\r' })
        "\"${value.replace("\"", "\"\"")}\"" else value

private fun parseCsv(text: String): List<List<String>> {
    val rows = mutableListOf<List<String>>()
    var row = mutableListOf<String>()
    val field = StringBuilder()
    var quoted = false
    var index = 0
    while (index < text.length) {
        val char = text[index]
        when {
            char == '"' && quoted && index + 1 < text.length && text[index + 1] == '"' -> {
                field.append('"'); index++
            }
            char == '"' -> quoted = !quoted
            char == ',' && !quoted -> { row += field.toString(); field.clear() }
            (char == '\n' || char == '\r') && !quoted -> {
                if (char == '\r' && index + 1 < text.length && text[index + 1] == '\n') index++
                row += field.toString(); field.clear()
                rows += row; row = mutableListOf()
            }
            else -> field.append(char)
        }
        index++
    }
    require(!quoted) { "CSV has an unterminated quoted field" }
    if (field.isNotEmpty() || row.isNotEmpty()) { row += field.toString(); rows += row }
    return rows
}
