package com.mystee.pantrypilot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mystee.pantrypilot.data.local.LocationEntity
import com.mystee.pantrypilot.data.local.MainCategoryEntity
import com.mystee.pantrypilot.data.local.SubcategoryEntity
import com.mystee.pantrypilot.data.local.UnitEntity
import com.mystee.pantrypilot.ui.components.AppIcons
import com.mystee.pantrypilot.ui.components.MessageCollector
import com.mystee.pantrypilot.ui.viewmodel.CatalogViewModel

private enum class ManageTab(val title: String) { LOCATIONS("Locations"), CATEGORIES("Categories"), UNITS("Units") }

@Composable
fun ManageScreen(viewModel: CatalogViewModel = hiltViewModel()) {
    val catalog by viewModel.catalog.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var tab by remember { mutableStateOf(ManageTab.LOCATIONS) }
    var editingLocation by remember { mutableStateOf<LocationEntity?>(null) }
    var addLocation by remember { mutableStateOf(false) }
    var editingMain by remember { mutableStateOf<MainCategoryEntity?>(null) }
    var editingUnit by remember { mutableStateOf<UnitEntity?>(null) }
    var addMain by remember { mutableStateOf(false) }
    var addUnit by remember { mutableStateOf(false) }
    var subForMain by remember { mutableStateOf<MainCategoryEntity?>(null) }
    var editingSub by remember { mutableStateOf<SubcategoryEntity?>(null) }
    MessageCollector(viewModel.messages) { snackbar.showSnackbar(it) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                when (tab) {
                    ManageTab.LOCATIONS -> addLocation = true
                    ManageTab.CATEGORIES -> addMain = true
                    ManageTab.UNITS -> addUnit = true
                }
            }) { Icon(Icons.Default.Add, "Add") }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Text(
                "Organize",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(16.dp)
            )
            TabRow(selectedTabIndex = tab.ordinal) {
                ManageTab.entries.forEach { candidate ->
                    Tab(selected = tab == candidate, onClick = { tab = candidate }, text = { Text(candidate.title) })
                }
            }
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (tab) {
                    ManageTab.LOCATIONS -> items(items = catalog.locations, key = { it.id }) { location ->
                        CatalogCard(
                            title = location.name,
                            leading = { Icon(AppIcons.fromKey(location.icon), null, tint = Color(location.colorArgb)) },
                            onEdit = { editingLocation = location },
                            onDelete = { viewModel.delete(location) }
                        )
                    }
                    ManageTab.CATEGORIES -> items(items = catalog.mainCategories, key = { it.id }) { main ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(main.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { subForMain = main }) { Text("+ Subcategory") }
                                    IconButton(onClick = { editingMain = main }) { Icon(Icons.Default.Edit, "Edit") }
                                    IconButton(onClick = { viewModel.delete(main) }) { Icon(Icons.Default.Delete, "Delete") }
                                }
                                catalog.subcategories.filter { it.mainCategoryId == main.id }.forEach { sub ->
                                    Row(
                                        Modifier.fillMaxWidth().padding(start = 18.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("• ${sub.name}", modifier = Modifier.weight(1f))
                                        IconButton(onClick = { editingSub = sub; subForMain = main }) { Icon(Icons.Default.Edit, "Edit") }
                                        IconButton(onClick = { viewModel.delete(sub) }) { Icon(Icons.Default.Delete, "Delete") }
                                    }
                                }
                            }
                        }
                    }
                    ManageTab.UNITS -> items(items = catalog.units, key = { it.id }) { unit ->
                        CatalogCard(
                            title = "${unit.name} (${unit.abbreviation})",
                            onEdit = { editingUnit = unit },
                            onDelete = { viewModel.delete(unit) }
                        )
                    }
                }
            }
        }
    }

    if (addLocation || editingLocation != null) {
        LocationEditor(
            value = editingLocation,
            onDismiss = { addLocation = false; editingLocation = null },
            onSave = { viewModel.save(it, editingLocation != null); addLocation = false; editingLocation = null }
        )
    }
    if (addMain || editingMain != null) {
        NameDialog(
            title = if (editingMain == null) "Add main category" else "Edit main category",
            initial = editingMain?.name.orEmpty(),
            onDismiss = { addMain = false; editingMain = null },
            onSave = { name ->
                viewModel.save(editingMain?.copy(name = name) ?: MainCategoryEntity(name = name), editingMain != null)
                addMain = false; editingMain = null
            }
        )
    }
    subForMain?.let { main ->
        NameDialog(
            title = if (editingSub == null) "Add subcategory to ${main.name}" else "Edit subcategory",
            initial = editingSub?.name.orEmpty(),
            onDismiss = { subForMain = null; editingSub = null },
            onSave = { name ->
                viewModel.save(
                    editingSub?.copy(name = name) ?: SubcategoryEntity(mainCategoryId = main.id, name = name),
                    editingSub != null
                )
                subForMain = null; editingSub = null
            }
        )
    }
    if (addUnit || editingUnit != null) {
        UnitDialog(
            value = editingUnit,
            onDismiss = { addUnit = false; editingUnit = null },
            onSave = { viewModel.save(it, editingUnit != null); addUnit = false; editingUnit = null }
        )
    }
}

@Composable
private fun CatalogCard(
    title: String,
    leading: (@Composable () -> Unit)? = null,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            leading?.invoke()
            Text(title, modifier = Modifier.weight(1f).padding(start = if (leading == null) 0.dp else 12.dp))
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Edit") }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LocationEditor(value: LocationEntity?, onDismiss: () -> Unit, onSave: (LocationEntity) -> Unit) {
    var name by remember(value?.id) { mutableStateOf(value?.name.orEmpty()) }
    var icon by remember(value?.id) { mutableStateOf(value?.icon ?: AppIcons.choices.keys.first()) }
    var color by remember(value?.id) { mutableStateOf(value?.colorArgb ?: LOCATION_COLORS.first()) }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(if (value == null) "Add location" else "Edit location", style = MaterialTheme.typography.headlineSmall)
            OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
            Text("Icon")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppIcons.choices.forEach { (key, image) ->
                    IconButton(
                        onClick = { icon = key },
                        modifier = Modifier.background(
                            if (icon == key) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                            CircleShape
                        )
                    ) { Icon(image, key) }
                }
            }
            Text("Color")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LOCATION_COLORS.forEach { candidate ->
                    Box(
                        Modifier.size(if (color == candidate) 34.dp else 28.dp)
                            .clip(CircleShape).background(Color(candidate)).clickable { color = candidate }
                    )
                }
            }
            Button(
                enabled = name.isNotBlank(),
                onClick = { onSave(value?.copy(name = name.trim(), icon = icon, colorArgb = color) ?: LocationEntity(name = name.trim(), icon = icon, colorArgb = color)) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save") }
        }
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var name by remember(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(name, { name = it }, label = { Text("Name") }) },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onSave(name.trim()) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun UnitDialog(value: UnitEntity?, onDismiss: () -> Unit, onSave: (UnitEntity) -> Unit) {
    var name by remember(value?.id) { mutableStateOf(value?.name.orEmpty()) }
    var abbreviation by remember(value?.id) { mutableStateOf(value?.abbreviation.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (value == null) "Add unit" else "Edit unit") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") })
                OutlinedTextField(abbreviation, { abbreviation = it }, label = { Text("Abbreviation") })
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank() && abbreviation.isNotBlank(),
                onClick = { onSave(value?.copy(name = name.trim(), abbreviation = abbreviation.trim()) ?: UnitEntity(name = name.trim(), abbreviation = abbreviation.trim())) }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private val LOCATION_COLORS = listOf(
    0xFF6750A4, 0xFF006874, 0xFF386A20, 0xFF9C4146, 0xFF7D5700, 0xFF4F5F7D
)
