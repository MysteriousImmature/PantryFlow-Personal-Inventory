package com.mystee.pantrypilot

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PantryPilotApplication : Application()
