package com.mystee.pantrypilot.di

import android.content.Context
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.mystee.pantrypilot.data.local.CatalogDao
import com.mystee.pantrypilot.data.local.GroceryListDao
import com.mystee.pantrypilot.data.local.ItemDao
import com.mystee.pantrypilot.data.local.PantryDatabase
import com.mystee.pantrypilot.data.local.SettingsDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): PantryDatabase =
        Room.databaseBuilder(context, PantryDatabase::class.java, PantryDatabase.NAME)
            .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
            .addCallback(object : RoomDatabase.Callback() {
                override fun onCreate(db: SupportSQLiteDatabase) {
                    super.onCreate(db)
                    seed(db)
                }
            })
            .build()

    @Provides fun provideItemDao(db: PantryDatabase): ItemDao = db.itemDao()
    @Provides fun provideCatalogDao(db: PantryDatabase): CatalogDao = db.catalogDao()
    @Provides fun provideGroceryListDao(db: PantryDatabase): GroceryListDao = db.groceryListDao()
    @Provides fun provideSettingsDao(db: PantryDatabase): SettingsDao = db.settingsDao()

    private fun seed(db: SupportSQLiteDatabase) {
        val now = System.currentTimeMillis()
        db.execSQL("INSERT INTO locations (id,name,icon,color_argb) VALUES ('loc-pantry','Pantry','pantry',4284633252)")
        db.execSQL("INSERT INTO locations (id,name,icon,color_argb) VALUES ('loc-fridge','Fridge','fridge',4280391411)")
        db.execSQL("INSERT INTO locations (id,name,icon,color_argb) VALUES ('loc-freezer','Freezer','freezer',4280760261)")
        db.execSQL("INSERT INTO main_categories (id,name) VALUES ('cat-food','Food')")
        db.execSQL("INSERT INTO main_categories (id,name) VALUES ('cat-household','Household')")
        db.execSQL("INSERT INTO subcategories (id,main_category_id,name) VALUES ('sub-produce','cat-food','Produce')")
        db.execSQL("INSERT INTO subcategories (id,main_category_id,name) VALUES ('sub-dairy','cat-food','Dairy')")
        db.execSQL("INSERT INTO subcategories (id,main_category_id,name) VALUES ('sub-dry','cat-food','Dry goods')")
        db.execSQL("INSERT INTO subcategories (id,main_category_id,name) VALUES ('sub-cleaning','cat-household','Cleaning')")
        db.execSQL("INSERT INTO units (id,name,abbreviation) VALUES ('unit-piece','Piece','pc')")
        db.execSQL("INSERT INTO units (id,name,abbreviation) VALUES ('unit-gram','Gram','g')")
        db.execSQL("INSERT INTO units (id,name,abbreviation) VALUES ('unit-kilogram','Kilogram','kg')")
        db.execSQL("INSERT INTO units (id,name,abbreviation) VALUES ('unit-milliliter','Milliliter','ml')")
        db.execSQL("INSERT INTO units (id,name,abbreviation) VALUES ('unit-liter','Liter','L')")
        db.execSQL("INSERT INTO grocery_lists (id,name,budget_cents,is_archived,created_at) VALUES ('list-default','Groceries',0,0,$now)")
        db.execSQL("INSERT INTO app_settings (`key`,value) VALUES ('theme_mode','SYSTEM')")
    }
}
