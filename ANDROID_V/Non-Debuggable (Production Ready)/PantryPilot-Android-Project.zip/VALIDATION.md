# Validation record

Performed on 2026-07-13:

- Parsed all Kotlin production and instrumentation-test sources with the Kotlin 2.4 compiler frontend: no syntax, import-placement, redeclaration, or conflicting-overload errors.
- Parsed every Android XML resource and the manifest successfully.
- Verified the Gradle wrapper JAR archive and pinned the Gradle 9.4.1 distribution SHA-256.
- Executed the equivalent SQLite v1 schema in memory with foreign keys enabled.
- Verified that consuming cannot produce negative stock.
- Verified that one-tap restock adds `to_buy_quantity` to `in_stock_quantity`, clears shopping state, and removes the item from the active list.
- Verified that `ForeignKey.RESTRICT` prevents deleting a location that still owns an item.
- Verified `PRAGMA foreign_key_check` returns no violations after lifecycle transitions.
- Confirmed the manifest declares no permissions and specifically no `INTERNET` permission.
- Completed a clean optimized release build with Gradle 9.4.1, Android SDK Platform 37.0, Build Tools 36.0.0, Kotlin/Compose compilation, Room KSP generation, Hilt code generation, R8, resource shrinking, DEX/resource packaging, alignment, and release signing.
- Verified the compiled APK ZIP structure with `unzip -t`.
- Verified Android APK Signature Schemes v2 and v3 with `apksigner` and verified ZIP alignment with `zipalign`.
- Inspected the packaged manifest: application ID `com.mystee.pantrypilot`, version `1.0.0`, minimum SDK 26, target SDK 37, `debuggable=false`, and no `INTERNET` permission.
- Signed with a dedicated 4096-bit RSA release certificate whose SHA-256 digest is `573901c5add8da4d77571000660a7995b5011d36e9e1014670b349850ed34aa5`.
- Final APK SHA-256: `d25b68b2a7105ba1a1a0edd3863b76fc1382cc437a61bb928851691412a74fa7`.

Release lint was not executed in this offline build because its desktop-only Material Icons lint artifact was unavailable. The instrumentation test suite still requires an Android device or emulator. Run `./gradlew lintRelease connectedCheck` in a fully provisioned Android environment before Play distribution.
