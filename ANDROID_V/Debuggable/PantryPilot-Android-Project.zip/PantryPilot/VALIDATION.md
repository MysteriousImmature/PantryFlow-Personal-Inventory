# Validation record

Performed on 2026-07-13:

- Parsed all Kotlin production and instrumentation-test sources with the Kotlin 2.4 compiler frontend: no syntax, import-placement, redeclaration, or conflicting-overload errors.
- Parsed every Android XML resource and the manifest successfully.
- Verified the Gradle wrapper JAR archive and pinned the Gradle 9.4.1 distribution SHA-256.
- Executed the equivalent SQLite v1 schema in memory with foreign keys enabled.
- Verified that consuming cannot produce negative stock.
- Verified that one-tap restock adds `to_buy_quantity` to `in_stock_quantity`, clears shopping state, and removes the item from the active list.
- Verified that `ForeignKey.RESTRICT` prevents deleting a location that still owns an item.
- Verified `PRAGMA foreign_key_check` returns no violations after lifecycle transitions.
- Confirmed the manifest declares no permissions and specifically no `INTERNET` permission.
- Completed a clean Android build with Gradle 9.4.1, Android SDK Platform 37.0, Build Tools 36.0.0, Kotlin/Compose compilation, Room KSP generation, Hilt code generation, D8, resource packaging, and APK signing.
- Verified the compiled APK ZIP structure with `unzip -t`.
- Verified its Android APK Signature Scheme v2 signature with `apksigner`.
- Inspected the packaged manifest with AAPT2: application ID `com.example.pantrypilot`, version `1.0.0`, minimum SDK 26, target SDK 37, and no `INTERNET` permission.

The instrumentation test suite still requires an Android device or emulator. Run `./gradlew connectedCheck` before producing a release-signed build.
