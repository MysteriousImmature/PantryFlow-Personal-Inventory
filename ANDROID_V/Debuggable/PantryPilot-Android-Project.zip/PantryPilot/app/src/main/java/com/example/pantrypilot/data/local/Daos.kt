package com.example.pantrypilot.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ItemDao {
    @Transaction
    @Query("SELECT * FROM items ORDER BY name COLLATE NOCASE")
    fun observeInventory(): Flow<List<ItemDetails>>

    @Transaction
    @Query("SELECT * FROM items WHERE grocery_list_id = :listId AND to_buy_quantity > 0 ORDER BY is_purchased, name COLLATE NOCASE")
    fun observeShoppingItems(listId: String): Flow<List<ItemDetails>>

    @Transaction
    @Query("SELECT * FROM items WHERE id = :id")
    suspend fun getDetails(id: String): ItemDetails?

    @Query("SELECT * FROM items WHERE id = :id")
    suspend fun get(id: String): ItemEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(item: ItemEntity)

    @Update
    suspend fun update(item: ItemEntity)

    @Delete
    suspend fun delete(item: ItemEntity)

    @Query("""
        UPDATE items
        SET in_stock_quantity = MAX(0, in_stock_quantity + :delta),
            updated_at = :updatedAt
        WHERE id = :itemId
    """)
    suspend fun adjustStock(itemId: String, delta: Double, updatedAt: Long): Int

    @Query("""
        UPDATE items
        SET in_stock_quantity = MAX(0, in_stock_quantity - :quantity),
            updated_at = :updatedAt
        WHERE id = :itemId AND :quantity > 0
    """)
    suspend fun consume(itemId: String, quantity: Double, updatedAt: Long): Int

    @Query("""
        UPDATE items
        SET grocery_list_id = :listId,
            to_buy_quantity = :quantity,
            is_purchased = 0,
            updated_at = :updatedAt
        WHERE id = :itemId AND :quantity > 0
          AND EXISTS (SELECT 1 FROM grocery_lists WHERE id = :listId AND is_archived = 0)
    """)
    suspend fun addToShoppingList(itemId: String, listId: String, quantity: Double, updatedAt: Long): Int

    @Query("""
        UPDATE items
        SET is_purchased = :purchased, updated_at = :updatedAt
        WHERE id = :itemId AND grocery_list_id IS NOT NULL AND to_buy_quantity > 0
    """)
    suspend fun setPurchased(itemId: String, purchased: Boolean, updatedAt: Long): Int

    @Query("""
        UPDATE items
        SET in_stock_quantity = in_stock_quantity + to_buy_quantity,
            to_buy_quantity = 0,
            is_purchased = 0,
            grocery_list_id = NULL,
            updated_at = :updatedAt
        WHERE grocery_list_id = :listId AND is_purchased = 1
    """)
    suspend fun restockPurchased(listId: String, updatedAt: Long): Int

    @Query("""
        UPDATE items
        SET to_buy_quantity = 0, is_purchased = 0, grocery_list_id = NULL, updated_at = :updatedAt
        WHERE id = :itemId
    """)
    suspend fun removeFromShoppingList(itemId: String, updatedAt: Long): Int

    @Transaction
    suspend fun restockPurchasedTransaction(listId: String, updatedAt: Long): Int =
        restockPurchased(listId, updatedAt)
}

@Dao
interface CatalogDao {
    @Query("SELECT * FROM locations ORDER BY name COLLATE NOCASE")
    fun observeLocations(): Flow<List<LocationEntity>>

    @Query("SELECT * FROM main_categories ORDER BY name COLLATE NOCASE")
    fun observeMainCategories(): Flow<List<MainCategoryEntity>>

    @Query("SELECT * FROM subcategories ORDER BY name COLLATE NOCASE")
    fun observeSubcategories(): Flow<List<SubcategoryEntity>>

    @Query("SELECT * FROM units ORDER BY name COLLATE NOCASE")
    fun observeUnits(): Flow<List<UnitEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertLocation(value: LocationEntity)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertMainCategory(value: MainCategoryEntity)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertSubcategory(value: SubcategoryEntity)
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insertUnit(value: UnitEntity)

    @Update suspend fun updateLocation(value: LocationEntity)
    @Update suspend fun updateMainCategory(value: MainCategoryEntity)
    @Update suspend fun updateSubcategory(value: SubcategoryEntity)
    @Update suspend fun updateUnit(value: UnitEntity)

    @Delete suspend fun deleteLocation(value: LocationEntity)
    @Delete suspend fun deleteMainCategory(value: MainCategoryEntity)
    @Delete suspend fun deleteSubcategory(value: SubcategoryEntity)
    @Delete suspend fun deleteUnit(value: UnitEntity)
}

@Dao
interface GroceryListDao {
    @Query("SELECT * FROM grocery_lists WHERE is_archived = 0 ORDER BY created_at DESC")
    fun observeActive(): Flow<List<GroceryListEntity>>

    @Query("SELECT * FROM grocery_lists ORDER BY is_archived, created_at DESC")
    fun observeAll(): Flow<List<GroceryListEntity>>

    @Query("SELECT * FROM grocery_lists WHERE id = :id")
    suspend fun get(id: String): GroceryListEntity?

    @Query("""
        SELECT grocery_lists.*,
            COUNT(items.id) AS item_count,
            COALESCE(SUM(CASE WHEN items.is_purchased = 1 THEN 1 ELSE 0 END), 0) AS purchased_count,
            CAST(COALESCE(SUM(CASE WHEN items.is_purchased = 1
                THEN items.to_buy_quantity * items.price_per_unit_cents ELSE 0 END), 0) AS INTEGER) AS purchased_cost_cents,
            CAST(COALESCE(SUM(CASE WHEN items.is_purchased = 0
                THEN items.to_buy_quantity * items.price_per_unit_cents ELSE 0 END), 0) AS INTEGER) AS remaining_estimated_cost_cents
        FROM grocery_lists
        LEFT JOIN items ON items.grocery_list_id = grocery_lists.id AND items.to_buy_quantity > 0
        GROUP BY grocery_lists.id
        ORDER BY grocery_lists.is_archived, grocery_lists.created_at DESC
    """)
    fun observeSummaries(): Flow<List<GroceryListSummary>>

    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(value: GroceryListEntity)
    @Update suspend fun update(value: GroceryListEntity)
    @Delete suspend fun delete(value: GroceryListEntity)
}

@Dao
interface SettingsDao {
    @Query("SELECT value FROM app_settings WHERE `key` = :key")
    fun observe(key: String): Flow<String?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(value: AppSettingEntity)
}
