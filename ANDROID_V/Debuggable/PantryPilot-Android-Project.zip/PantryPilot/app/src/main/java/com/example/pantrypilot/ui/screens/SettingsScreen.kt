package com.example.pantrypilot.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.pantrypilot.data.local.RestoreMode
import com.example.pantrypilot.data.local.ThemeMode
import com.example.pantrypilot.ui.components.MessageCollector
import com.example.pantrypilot.ui.viewmodel.SettingsViewModel
import java.time.LocalDate

@Composable
fun SettingsScreen(viewModel: SettingsViewModel = hiltViewModel()) {
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()
    val pendingRestore by viewModel.pendingRestore.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var restoreMode by remember { mutableStateOf(RestoreMode.MERGE) }
    MessageCollector(viewModel.messages) { snackbar.showSnackbar(it) }

    val sqlExport = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/sql")
    ) { uri -> uri?.let(viewModel::exportSql) }
    val csvExport = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri -> uri?.let(viewModel::exportCsvZip) }
    val restore = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { viewModel.previewRestore(it, restoreMode) } }
    val csvRestore = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) viewModel.previewCsvRestore(uris, restoreMode) }

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Appearance", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ThemeMode.entries.forEach { mode ->
                    FilterChip(
                        selected = themeMode == mode,
                        onClick = { viewModel.setThemeMode(mode) },
                        label = { Text(mode.name.lowercase().replaceFirstChar(Char::uppercase)) }
                    )
                }
            }

            Text("Backup", style = MaterialTheme.typography.titleMedium)
            Text("Exports contain every table and stay entirely on the device location you choose.")
            Button(
                enabled = !busy,
                onClick = { sqlExport.launch("pantry-pilot-${LocalDate.now()}.sql") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Download, null)
                Text("  Export SQL backup")
            }
            OutlinedButton(
                enabled = !busy,
                onClick = { csvExport.launch("pantry-pilot-${LocalDate.now()}.csv.zip") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Download, null)
                Text("  Export CSV files as ZIP")
            }

            Text("Restore mode", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RestoreMode.entries.forEach { mode ->
                    FilterChip(
                        selected = restoreMode == mode,
                        onClick = { restoreMode = mode },
                        label = { Text(mode.name.lowercase().replaceFirstChar(Char::uppercase)) }
                    )
                }
            }
            if (restoreMode == RestoreMode.REPLACE) {
                Text("Replace deletes current app data only after the selected backup passes validation.", color = MaterialTheme.colorScheme.error)
            }
            Button(
                enabled = !busy,
                onClick = { restore.launch(arrayOf("application/sql", "application/zip", "text/csv", "text/plain")) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Upload, null)
                Text("  Restore SQL or CSV ZIP")
            }
            OutlinedButton(
                enabled = !busy,
                onClick = { csvRestore.launch(arrayOf("text/csv", "text/comma-separated-values", "text/plain")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Restore selected CSV files") }

            if (busy) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator()
                    Text("Validating…")
                }
            }
            Text(
                "Offline guarantee: the manifest contains no INTERNET permission, and Android cloud backup is disabled.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    pendingRestore?.let { plan ->
        AlertDialog(
            onDismissRequest = viewModel::cancelRestore,
            title = { Text("Restore ${plan.summary.format} backup?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Mode: ${plan.mode.name.lowercase()}")
                    plan.summary.tableCounts.forEach { (table, count) -> Text("$table: $count row(s)") }
                    if (plan.mode == RestoreMode.REPLACE) {
                        Text("This will replace all current app data.", color = MaterialTheme.colorScheme.error)
                    }
                }
            },
            confirmButton = { TextButton(onClick = viewModel::confirmRestore) { Text("Restore") } },
            dismissButton = { TextButton(onClick = viewModel::cancelRestore) { Text("Cancel") } }
        )
    }
}
