package com.example.pantrypilot.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        ItemEntity::class,
        LocationEntity::class,
        GroceryListEntity::class,
        MainCategoryEntity::class,
        SubcategoryEntity::class,
        UnitEntity::class,
        AppSettingEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(DateConverters::class)
abstract class PantryDatabase : RoomDatabase() {
    abstract fun itemDao(): ItemDao
    abstract fun catalogDao(): CatalogDao
    abstract fun groceryListDao(): GroceryListDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        const val NAME = "pantry_pilot.db"
    }
}
