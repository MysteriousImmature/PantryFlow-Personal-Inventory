package com.example.pantrypilot.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.pantrypilot.ui.screens.ManageScreen
import com.example.pantrypilot.ui.screens.PantryScreen
import com.example.pantrypilot.ui.screens.SettingsScreen
import com.example.pantrypilot.ui.screens.ShoppingDetailScreen
import com.example.pantrypilot.ui.screens.ShoppingListsScreen

private data class Destination(val route: String, val label: String, val icon: ImageVector)

private val TOP_LEVEL = listOf(
    Destination("shopping", "Shopping", Icons.Default.ShoppingCart),
    Destination("pantry", "Pantry", Icons.Default.Inventory2),
    Destination("manage", "Organize", Icons.Default.Category),
    Destination("settings", "Settings", Icons.Default.Settings)
)

@Composable
fun PantryPilotApp() {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    Scaffold(
        bottomBar = {
            if (TOP_LEVEL.any { it.route == currentRoute }) {
                NavigationBar {
                    TOP_LEVEL.forEach { destination ->
                        NavigationBarItem(
                            selected = currentRoute == destination.route,
                            onClick = {
                                navController.navigate(destination.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(destination.icon, destination.label) },
                            label = { Text(destination.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = "shopping",
            modifier = Modifier.padding(padding)
        ) {
            composable("shopping") {
                ShoppingListsScreen(onOpenList = { navController.navigate("shopping/$it") })
            }
            composable("shopping/{listId}") {
                ShoppingDetailScreen(onBack = navController::popBackStack)
            }
            composable("pantry") { PantryScreen() }
            composable("manage") { ManageScreen() }
            composable("settings") { SettingsScreen() }
        }
    }
}
