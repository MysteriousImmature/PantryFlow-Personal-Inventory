package com.example.pantrypilot.data.local

import androidx.room.Embedded
import androidx.room.ColumnInfo
import androidx.room.Relation
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class ItemDetails(
    @Embedded val item: ItemEntity,
    @Relation(parentColumn = "location_id", entityColumn = "id")
    val location: LocationEntity,
    @Relation(parentColumn = "main_category_id", entityColumn = "id")
    val mainCategory: MainCategoryEntity,
    @Relation(parentColumn = "subcategory_id", entityColumn = "id")
    val subcategory: SubcategoryEntity?,
    @Relation(parentColumn = "unit_id", entityColumn = "id")
    val unit: UnitEntity,
    @Relation(parentColumn = "grocery_list_id", entityColumn = "id")
    val groceryList: GroceryListEntity?
)

data class GroceryListSummary(
    @Embedded val list: GroceryListEntity,
    @ColumnInfo(name = "item_count") val itemCount: Int,
    @ColumnInfo(name = "purchased_count") val purchasedCount: Int,
    @ColumnInfo(name = "purchased_cost_cents") val purchasedCostCents: Long,
    @ColumnInfo(name = "remaining_estimated_cost_cents") val remainingEstimatedCostCents: Long
) {
    val remainingBudgetCents: Long get() = list.budgetCents - purchasedCostCents
}

enum class ExpiryState { FRESH, EXPIRING_SOON, EXPIRED }

fun ItemEntity.expiryState(today: LocalDate = LocalDate.now()): ExpiryState {
    val date = expirationDate ?: return ExpiryState.FRESH
    val days = ChronoUnit.DAYS.between(today, date)
    return when {
        days < 0 -> ExpiryState.EXPIRED
        days <= 7 -> ExpiryState.EXPIRING_SOON
        else -> ExpiryState.FRESH
    }
}

data class CatalogSnapshot(
    val locations: List<LocationEntity> = emptyList(),
    val mainCategories: List<MainCategoryEntity> = emptyList(),
    val subcategories: List<SubcategoryEntity> = emptyList(),
    val units: List<UnitEntity> = emptyList(),
    val groceryLists: List<GroceryListEntity> = emptyList()
)

data class LowStockPrompt(
    val item: ItemDetails,
    val suggestedQuantity: Double
)

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class BackupSummary(
    val format: String,
    val tableCounts: Map<String, Int>,
    val warnings: List<String> = emptyList()
) {
    val itemCount: Int get() = tableCounts["items"] ?: 0
}

enum class RestoreMode { MERGE, REPLACE }
