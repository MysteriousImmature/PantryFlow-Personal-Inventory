package com.example.pantrypilot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.pantrypilot.ui.PantryPilotApp
import com.example.pantrypilot.ui.theme.PantryPilotTheme
import com.example.pantrypilot.ui.viewmodel.AppViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: AppViewModel = hiltViewModel()
            val themeMode = viewModel.themeMode.collectAsStateWithLifecycle().value
            PantryPilotTheme(themeMode) { PantryPilotApp() }
        }
    }
}
