package com.example.pantrypilot.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import java.time.Instant
import java.time.LocalDate
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()

@Entity(tableName = "locations", indices = [Index("name")])
data class LocationEntity(
    @PrimaryKey val id: String = newId(),
    val name: String,
    /** A key from AppIcons, not a platform resource id. */
    val icon: String = "pantry",
    @ColumnInfo(name = "color_argb") val colorArgb: Long = 0xFF6750A4
)

@Entity(tableName = "main_categories", indices = [Index("name")])
data class MainCategoryEntity(
    @PrimaryKey val id: String = newId(),
    val name: String
)

@Entity(
    tableName = "subcategories",
    foreignKeys = [
        ForeignKey(
            entity = MainCategoryEntity::class,
            parentColumns = ["id"],
            childColumns = ["main_category_id"],
            onDelete = ForeignKey.RESTRICT,
            onUpdate = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("main_category_id"),
        Index(value = ["id", "main_category_id"], unique = true),
        Index(value = ["main_category_id", "name"])
    ]
)
data class SubcategoryEntity(
    @PrimaryKey val id: String = newId(),
    @ColumnInfo(name = "main_category_id") val mainCategoryId: String,
    val name: String
)

@Entity(tableName = "units", indices = [Index("name")])
data class UnitEntity(
    @PrimaryKey val id: String = newId(),
    val name: String,
    val abbreviation: String
)

@Entity(tableName = "grocery_lists", indices = [Index("is_archived")])
data class GroceryListEntity(
    @PrimaryKey val id: String = newId(),
    val name: String,
    @ColumnInfo(name = "budget_cents") val budgetCents: Long = 0,
    @ColumnInfo(name = "is_archived") val isArchived: Boolean = false,
    @ColumnInfo(name = "created_at") val createdAt: Instant = Instant.now()
)

@Entity(
    tableName = "items",
    foreignKeys = [
        ForeignKey(
            entity = LocationEntity::class,
            parentColumns = ["id"], childColumns = ["location_id"],
            onDelete = ForeignKey.RESTRICT, onUpdate = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = MainCategoryEntity::class,
            parentColumns = ["id"], childColumns = ["main_category_id"],
            onDelete = ForeignKey.RESTRICT, onUpdate = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = SubcategoryEntity::class,
            parentColumns = ["id", "main_category_id"],
            childColumns = ["subcategory_id", "main_category_id"],
            onDelete = ForeignKey.RESTRICT, onUpdate = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = UnitEntity::class,
            parentColumns = ["id"], childColumns = ["unit_id"],
            onDelete = ForeignKey.RESTRICT, onUpdate = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = GroceryListEntity::class,
            parentColumns = ["id"], childColumns = ["grocery_list_id"],
            onDelete = ForeignKey.RESTRICT, onUpdate = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("location_id"), Index("main_category_id"),
        Index("subcategory_id"), Index("unit_id"), Index("grocery_list_id"),
        Index(value = ["subcategory_id", "main_category_id"]), Index("name")
    ]
)
data class ItemEntity(
    @PrimaryKey val id: String = newId(),
    val name: String,
    @ColumnInfo(name = "location_id") val locationId: String,
    @ColumnInfo(name = "main_category_id") val mainCategoryId: String,
    @ColumnInfo(name = "subcategory_id") val subcategoryId: String? = null,
    @ColumnInfo(name = "unit_id") val unitId: String,
    /** Null when this item is not currently assigned to a shopping list. */
    @ColumnInfo(name = "grocery_list_id") val groceryListId: String? = null,
    @ColumnInfo(name = "in_stock_quantity") val inStockQuantity: Double = 0.0,
    @ColumnInfo(name = "to_buy_quantity") val toBuyQuantity: Double = 0.0,
    @ColumnInfo(name = "low_stock_threshold") val lowStockThreshold: Double = 0.0,
    @ColumnInfo(name = "price_per_unit_cents") val pricePerUnitCents: Long = 0,
    @ColumnInfo(name = "expiration_date") val expirationDate: LocalDate? = null,
    @ColumnInfo(name = "is_purchased") val isPurchased: Boolean = false,
    @ColumnInfo(name = "created_at") val createdAt: Instant = Instant.now(),
    @ColumnInfo(name = "updated_at") val updatedAt: Instant = Instant.now()
)

@Entity(tableName = "app_settings")
data class AppSettingEntity(
    @PrimaryKey val key: String,
    val value: String
)

class DateConverters {
    @TypeConverter fun instantToLong(value: Instant?): Long? = value?.toEpochMilli()
    @TypeConverter fun longToInstant(value: Long?): Instant? = value?.let(Instant::ofEpochMilli)
    @TypeConverter fun localDateToString(value: LocalDate?): String? = value?.toString()
    @TypeConverter fun stringToLocalDate(value: String?): LocalDate? = value?.let(LocalDate::parse)
}
