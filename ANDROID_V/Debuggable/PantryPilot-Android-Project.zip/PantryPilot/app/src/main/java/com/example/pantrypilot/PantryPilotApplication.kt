package com.example.pantrypilot

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PantryPilotApplication : Application()
