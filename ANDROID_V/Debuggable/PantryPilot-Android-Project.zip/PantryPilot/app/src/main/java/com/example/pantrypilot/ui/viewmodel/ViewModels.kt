package com.example.pantrypilot.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pantrypilot.data.backup.BackupManager
import com.example.pantrypilot.data.backup.RestorePlan
import com.example.pantrypilot.data.local.BackupSummary
import com.example.pantrypilot.data.local.CatalogSnapshot
import com.example.pantrypilot.data.local.GroceryListEntity
import com.example.pantrypilot.data.local.GroceryListSummary
import com.example.pantrypilot.data.local.ItemDetails
import com.example.pantrypilot.data.local.ItemEntity
import com.example.pantrypilot.data.local.LocationEntity
import com.example.pantrypilot.data.local.LowStockPrompt
import com.example.pantrypilot.data.local.MainCategoryEntity
import com.example.pantrypilot.data.local.RestoreMode
import com.example.pantrypilot.data.local.SubcategoryEntity
import com.example.pantrypilot.data.local.ThemeMode
import com.example.pantrypilot.data.local.UnitEntity
import com.example.pantrypilot.data.repository.CatalogRepository
import com.example.pantrypilot.data.repository.InventoryRepository
import com.example.pantrypilot.data.repository.SettingsRepository
import com.example.pantrypilot.data.repository.ShoppingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class InventoryGroup { LOCATION, CATEGORY }

private const val STOP_TIMEOUT = 5_000L

@HiltViewModel
class AppViewModel @Inject constructor(settings: SettingsRepository) : ViewModel() {
    val themeMode = settings.themeMode.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), ThemeMode.SYSTEM
    )
}

@HiltViewModel
class PantryViewModel @Inject constructor(
    private val inventoryRepository: InventoryRepository,
    catalogRepository: CatalogRepository,
    shoppingRepository: ShoppingRepository
) : ViewModel() {
    val inventory: StateFlow<List<ItemDetails>> = inventoryRepository.inventory.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), emptyList()
    )
    val catalog: StateFlow<CatalogSnapshot> = catalogRepository.snapshot.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), CatalogSnapshot()
    )
    val activeLists: StateFlow<List<GroceryListEntity>> = shoppingRepository.activeLists.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), emptyList()
    )
    val group = MutableStateFlow(InventoryGroup.LOCATION)

    private val _lowStockPrompt = MutableStateFlow<LowStockPrompt?>(null)
    val lowStockPrompt = _lowStockPrompt.asStateFlow()
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages = _messages.asSharedFlow()

    fun save(item: ItemEntity) = launchAction("Item saved") { inventoryRepository.save(item) }
    fun delete(item: ItemEntity) = launchAction("Item deleted") { inventoryRepository.delete(item) }
    fun increment(itemId: String) = launchAction { inventoryRepository.increment(itemId) }

    fun consume(itemId: String, amount: Double = 1.0) = launchAction {
        _lowStockPrompt.value = inventoryRepository.consume(itemId, amount)
    }

    fun addLowStockToList(listId: String, quantity: Double) {
        val prompt = _lowStockPrompt.value ?: return
        launchAction("Added to shopping list") {
            inventoryRepository.addLowStockToList(prompt.item.item.id, listId, quantity)
            _lowStockPrompt.value = null
        }
    }

    fun dismissLowStock() { _lowStockPrompt.value = null }

    private fun launchAction(success: String? = null, block: suspend () -> Unit) = viewModelScope.launch {
        runCatching { block() }
            .onSuccess { success?.let(_messages::tryEmit) }
            .onFailure { _messages.emit(it.userMessage()) }
    }
}

@HiltViewModel
class ShoppingListsViewModel @Inject constructor(
    private val repository: ShoppingRepository
) : ViewModel() {
    val summaries: StateFlow<List<GroceryListSummary>> = repository.summaries.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), emptyList()
    )
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages = _messages.asSharedFlow()

    fun save(value: GroceryListEntity) = viewModelScope.launch {
        runCatching { repository.saveList(value) }
            .onSuccess { _messages.emit("List saved") }
            .onFailure { _messages.emit(it.userMessage()) }
    }
}

@HiltViewModel
class ShoppingDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: ShoppingRepository
) : ViewModel() {
    val listId: String = checkNotNull(savedStateHandle["listId"])
    val items: StateFlow<List<ItemDetails>> = repository.items(listId).stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), emptyList()
    )
    val summaries: StateFlow<List<GroceryListSummary>> = repository.summaries.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), emptyList()
    )
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages = _messages.asSharedFlow()

    fun setPurchased(itemId: String, value: Boolean) = launchAction {
        repository.setPurchased(itemId, value)
    }

    fun remove(itemId: String) = launchAction("Removed from list") { repository.removeItem(itemId) }

    fun finishShopping() = launchAction {
        val count = repository.finishShopping(listId)
        _messages.emit(if (count == 0) "No purchased items to restock" else "$count item(s) moved to pantry")
    }

    private fun launchAction(success: String? = null, block: suspend () -> Unit) = viewModelScope.launch {
        runCatching { block() }
            .onSuccess { success?.let { _messages.emit(it) } }
            .onFailure { _messages.emit(it.userMessage()) }
    }
}

@HiltViewModel
class CatalogViewModel @Inject constructor(private val repository: CatalogRepository) : ViewModel() {
    val catalog = repository.snapshot.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), CatalogSnapshot()
    )
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages = _messages.asSharedFlow()

    fun save(value: LocationEntity, exists: Boolean) = action { repository.save(value, exists) }
    fun save(value: MainCategoryEntity, exists: Boolean) = action { repository.save(value, exists) }
    fun save(value: SubcategoryEntity, exists: Boolean) = action { repository.save(value, exists) }
    fun save(value: UnitEntity, exists: Boolean) = action { repository.save(value, exists) }
    fun delete(value: LocationEntity) = action { repository.delete(value) }
    fun delete(value: MainCategoryEntity) = action { repository.delete(value) }
    fun delete(value: SubcategoryEntity) = action { repository.delete(value) }
    fun delete(value: UnitEntity) = action { repository.delete(value) }

    private fun action(block: suspend () -> Unit) = viewModelScope.launch {
        runCatching { block() }
            .onSuccess { _messages.emit("Saved") }
            .onFailure { error ->
                val message = if (error.message.orEmpty().contains("FOREIGN KEY", true))
                    "This entry is in use. Move or delete its items first."
                else error.userMessage()
                _messages.emit(message)
            }
    }
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val backupManager: BackupManager,
    private val settingsRepository: SettingsRepository
) : ViewModel() {
    val themeMode = settingsRepository.themeMode.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT), ThemeMode.SYSTEM
    )
    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()
    private val _pendingRestore = MutableStateFlow<RestorePlan?>(null)
    val pendingRestore = _pendingRestore.asStateFlow()
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages = _messages.asSharedFlow()

    fun setThemeMode(value: ThemeMode) = runBusy { settingsRepository.setThemeMode(value) }
    fun exportSql(uri: Uri) = runBusy("SQL backup exported") { backupManager.exportSql(uri) }
    fun exportCsvZip(uri: Uri) = runBusy("CSV ZIP exported") { backupManager.exportCsvZip(uri) }

    fun previewRestore(uri: Uri, mode: RestoreMode) = runBusy {
        _pendingRestore.value = backupManager.preview(uri, mode)
    }

    fun previewCsvRestore(uris: List<Uri>, mode: RestoreMode) = runBusy {
        _pendingRestore.value = backupManager.previewCsvFiles(uris, mode)
    }

    fun confirmRestore() {
        val plan = _pendingRestore.value ?: return
        runBusy("Restore complete: ${plan.summary.itemCount} item(s)") {
            backupManager.restore(plan)
            _pendingRestore.value = null
        }
    }

    fun cancelRestore() { _pendingRestore.value = null }

    private fun runBusy(success: String? = null, block: suspend () -> Any?) = viewModelScope.launch {
        _busy.value = true
        runCatching { block() }
            .onSuccess { success?.let { _messages.emit(it) } }
            .onFailure { _messages.emit(it.userMessage()) }
        _busy.value = false
    }
}

private fun Throwable.userMessage(): String = message?.takeIf(String::isNotBlank) ?: "Something went wrong"
