package com.example.pantrypilot.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.example.pantrypilot.data.local.ExpiryState
import com.example.pantrypilot.data.local.ItemDetails
import com.example.pantrypilot.data.local.expiryState
import com.example.pantrypilot.ui.components.DropdownSelector
import com.example.pantrypilot.ui.components.ItemEditorSheet
import com.example.pantrypilot.ui.components.MessageCollector
import com.example.pantrypilot.ui.viewmodel.InventoryGroup
import com.example.pantrypilot.ui.viewmodel.PantryViewModel

@Composable
fun PantryScreen(viewModel: PantryViewModel = hiltViewModel()) {
    val inventory by viewModel.inventory.collectAsStateWithLifecycle()
    val catalog by viewModel.catalog.collectAsStateWithLifecycle()
    val lists by viewModel.activeLists.collectAsStateWithLifecycle()
    val group by viewModel.group.collectAsStateWithLifecycle()
    val lowStock by viewModel.lowStockPrompt.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var editing by remember { mutableStateOf<ItemDetails?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<ItemDetails?>(null) }

    MessageCollector(viewModel.messages) { snackbar.showSnackbar(it) }
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Default.Add, "Add item") }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Pantry inventory", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssistChip(
                        onClick = { viewModel.group.value = InventoryGroup.LOCATION },
                        label = { Text(if (group == InventoryGroup.LOCATION) "✓ Location" else "Location") }
                    )
                    AssistChip(
                        onClick = { viewModel.group.value = InventoryGroup.CATEGORY },
                        label = { Text(if (group == InventoryGroup.CATEGORY) "✓ Category" else "Category") }
                    )
                }
            }
            if (inventory.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No items yet. Tap + to add your first item.")
                }
            } else {
                val grouped = inventory.groupBy {
                    if (group == InventoryGroup.LOCATION) it.location.name else it.mainCategory.name
                }.toSortedMap(String.CASE_INSENSITIVE_ORDER)
                LazyColumn(
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    grouped.forEach { (header, groupItems) ->
                        item(key = "header-$header") {
                            Text(
                                header,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(top = 12.dp, start = 4.dp)
                            )
                        }
                        items(count = groupItems.size, key = { groupItems[it].item.id }) { index ->
                            InventoryCard(
                                details = groupItems[index],
                                onMinus = { viewModel.consume(groupItems[index].item.id) },
                                onPlus = { viewModel.increment(groupItems[index].item.id) },
                                onEdit = { editing = groupItems[index] },
                                onDelete = { deleting = groupItems[index] }
                            )
                        }
                    }
                }
            }
        }
    }

    if (adding || editing != null) {
        ItemEditorSheet(
            item = editing?.item,
            catalog = catalog,
            groceryLists = lists,
            onDismiss = { adding = false; editing = null },
            onSave = viewModel::save
        )
    }

    lowStock?.let { prompt ->
        var quantity by remember(prompt.item.item.id) { mutableStateOf(prompt.suggestedQuantity.toString()) }
        var listId by remember(prompt.item.item.id) { mutableStateOf(lists.firstOrNull()?.id) }
        AlertDialog(
            onDismissRequest = viewModel::dismissLowStock,
            icon = { Icon(Icons.Default.Warning, null) },
            title = { Text("${prompt.item.item.name} is low") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Only ${prompt.item.item.inStockQuantity} ${prompt.item.unit.abbreviation} remains.")
                    androidx.compose.material3.OutlinedTextField(
                        quantity, { quantity = it }, label = { Text("Quantity to buy") }
                    )
                    if (lists.isEmpty()) Text("Create a grocery list before adding this item.")
                    else DropdownSelector(
                        "Grocery list", lists, lists.firstOrNull { it.id == listId },
                        { it.name }, { listId = it.id }
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = listId != null && (quantity.toDoubleOrNull() ?: 0.0) > 0,
                    onClick = { viewModel.addLowStockToList(listId!!, quantity.toDouble()) }
                ) { Text("Add to list") }
            },
            dismissButton = { TextButton(onClick = viewModel::dismissLowStock) { Text("Not now") } }
        )
    }

    deleting?.let { details ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete ${details.item.name}?") },
            text = { Text("This removes the item from both pantry and any shopping list.") },
            confirmButton = {
                TextButton(onClick = { viewModel.delete(details.item); deleting = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun InventoryCard(
    details: ItemDetails,
    onMinus: () -> Unit,
    onPlus: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val expiry = details.item.expiryState()
    val container = when (expiry) {
        ExpiryState.EXPIRED -> MaterialTheme.colorScheme.errorContainer
        ExpiryState.EXPIRING_SOON -> Color(0xFFFFF1C2)
        ExpiryState.FRESH -> MaterialTheme.colorScheme.surfaceVariant
    }
    Card(colors = CardDefaults.cardColors(containerColor = container), modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(details.item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("${details.subcategory?.name ?: details.mainCategory.name} • ${details.location.name}")
                details.item.expirationDate?.let { date ->
                    Text(
                        if (expiry == ExpiryState.EXPIRED) "Expired $date" else "Expires $date",
                        color = if (expiry == ExpiryState.EXPIRED) MaterialTheme.colorScheme.error else Color(0xFF795900)
                    )
                }
                if (details.item.inStockQuantity < details.item.lowStockThreshold) {
                    Text("Low stock", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Medium)
                }
            }
            IconButton(onClick = onMinus) { Icon(Icons.Default.Remove, "Consume one") }
            Text(
                "${details.item.inStockQuantity} ${details.unit.abbreviation}",
                style = MaterialTheme.typography.titleMedium
            )
            IconButton(onClick = onPlus) { Icon(Icons.Default.Add, "Add one") }
            Spacer(Modifier.width(4.dp))
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, "Edit") }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete") }
        }
    }
}
