# PantryPilot

PantryPilot is a native, offline-only Android grocery and household inventory app. It tracks one item from pantry stock, through low-stock detection and a named shopping list, back into stock after purchase. It uses Kotlin, Jetpack Compose, Material 3, MVVM, Hilt, Coroutines/Flow, Room 2.8.4, and SQLite.

The app declares **no `INTERNET` permission**, disables Android cloud backup, and performs no network calls. All persistent application data, including the theme preference, lives in Room on the device.

## Open and run

1. Open this directory in a current Android Studio version compatible with Android Gradle Plugin 9.2.1.
2. Install Android SDK 37 and use JDK 17.
3. Let Gradle sync, then run the `app` configuration on an API 26+ emulator or device.
4. Run the `ItemLifecycleTest` instrumentation tests to verify consume and restock transitions.

The first Gradle sync needs dependency access. The installed app itself is completely offline.

## Project structure

```text
PantryPilot/
├── app/
│   ├── schemas/                         Room schema exports
│   └── src/
│       ├── androidTest/.../ItemLifecycleTest.kt
│       └── main/
│           ├── AndroidManifest.xml      no INTERNET permission
│           ├── java/com/example/pantrypilot/
│           │   ├── MainActivity.kt
│           │   ├── PantryPilotApplication.kt
│           │   ├── data/
│           │   │   ├── backup/BackupManager.kt
│           │   │   ├── local/{Entities,Models,Daos,PantryDatabase}.kt
│           │   │   └── repository/Repositories.kt
│           │   ├── di/AppModule.kt
│           │   └── ui/
│           │       ├── PantryPilotApp.kt
│           │       ├── components/
│           │       ├── screens/
│           │       ├── theme/Theme.kt
│           │       └── viewmodel/ViewModels.kt
│           └── res/
├── gradle/libs.versions.toml
├── build.gradle.kts
└── settings.gradle.kts
```

## Architecture

```mermaid
flowchart TD
    UI[Compose screens] --> VM[Hilt ViewModels]
    VM --> R[Repositories]
    R --> D[Room DAOs]
    D --> S[(On-device SQLite)]
    UI --> SAF[Storage Access Framework]
    SAF --> B[Validated backup manager]
    B --> S
```

- Compose collects lifecycle-aware `StateFlow` values and uses stable item IDs as `LazyColumn` keys.
- ViewModels own UI state, messages, and low-stock prompts.
- Repositories validate user input and define lifecycle boundaries.
- DAOs perform atomic quantity changes. Room enforces all foreign keys.
- UUID string primary keys make merge restores safe across different devices.

## Data model

`ItemEntity` is the unified stock/shopping record. In addition to the requested fields, it has a nullable `groceryListId`; this is required to associate `toBuyQuantity` with one of multiple named lists. An item can be active on one list at a time. This avoids duplicate stock records and makes restocking atomic.

The schema contains:

- `items`
- `locations`
- `grocery_lists`
- `main_categories`
- `subcategories`
- `units`
- `app_settings`

Every catalog reference uses `ForeignKey.RESTRICT`. Items use a composite `(subcategory_id, main_category_id)` foreign key, so a subcategory cannot accidentally be paired with a different main category.

## Lifecycle rules

### Consume

`InventoryRepository.consume()` runs in a Room transaction. The SQL update subtracts the requested amount and clamps the result to zero. After the update, the repository checks the low-stock threshold. If the item is low and is not already on a list, the pantry screen offers a suggested quantity and an active grocery-list selector.

### Restock / Finish shopping

`ItemDao.restockPurchasedTransaction()` performs one set-based SQL update for the chosen list:

```sql
in_stock_quantity = in_stock_quantity + to_buy_quantity,
to_buy_quantity = 0,
is_purchased = 0,
grocery_list_id = NULL
```

Only rows marked purchased are changed. The whole operation commits or rolls back as one SQLite transaction.

## Backup and restore

Settings uses Android's Storage Access Framework, so the app never asks for broad filesystem access.

- **SQL export:** writes a versioned, app-compatible `.sql` document containing canonical UPSERT statements for every table.
- **CSV export:** writes a ZIP with a manifest and one RFC-4180-style CSV per table.
- **Restore:** accepts the app SQL format, CSV ZIP, or selected table CSV files.
- **Validation:** limits input size and row count; rejects unknown tables, unexpected columns, unsafe SQL shapes, malformed CSV/ZIP data, and broken foreign keys.
- **Preview:** performs a dry-run Room transaction and intentionally rolls it back before showing table/item counts.
- **Merge:** UPSERTs UUID-keyed rows.
- **Replace:** clears child tables before parents, then imports. Nothing is deleted unless validation passes and the user confirms.

## Production notes

- Room schema export is enabled. Commit generated JSON schemas before releasing migrations.
- Release builds enable R8 and resource shrinking.
- Change `applicationId`, app signing, and branding before Play distribution.
- Currency formatting follows the device locale; monetary values are stored as integer cents to avoid floating-point rounding in budgets.
- Quantities are `Double` to support pieces, weight, and volume. Prices remain integer cents.

## Dependency baseline (July 2026)

- [Android Gradle Plugin 9.2.1](https://developer.android.com/reference/tools/gradle-api)
- [Room 2.8.4](https://developer.android.com/jetpack/androidx/releases/room)
- [Compose BOM 2026.06.01](https://developer.android.com/develop/ui/compose/bom/bom-mapping)
- [Lifecycle 2.11.0](https://developer.android.com/jetpack/androidx/releases/lifecycle)
- [Navigation 2.9.8](https://developer.android.com/jetpack/androidx/releases/navigation)
- [Hilt / Dagger 2.60.1](https://dagger.dev/)
